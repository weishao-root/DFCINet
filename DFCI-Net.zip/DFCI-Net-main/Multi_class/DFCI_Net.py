from functools import partial
from dfci_net import build_model as _build, cb_focal_loss as _loss, fingerprints, train as _train

build_model = partial(_build, "multiclass")
cb_focal_loss = partial(_loss, "multiclass")
train = partial(_train, "multiclass")

__all__ = ["fingerprints", "build_model", "cb_focal_loss", "train"]
