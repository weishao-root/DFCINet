from functools import partial
from dfci_net import build_model as _build, cb_focal_loss as _loss, fingerprints, train as _train

build_model = partial(_build, "binary")
cb_focal_loss = partial(_loss, "binary")
train = partial(_train, "binary")

__all__ = ["fingerprints", "build_model", "cb_focal_loss", "train"]
