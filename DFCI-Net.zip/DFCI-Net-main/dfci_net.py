import numpy as np
import tensorflow as tf
from tensorflow import keras
from rdkit import Chem, DataStructs
from rdkit.Chem import AllChem, MACCSkeys


def fingerprints(smiles):
    """Return 1024-bit chiral Morgan (radius 2) and 167-bit MACCS vectors."""
    morgan = np.zeros(1024, dtype=np.float32)
    maccs = np.zeros(167, dtype=np.float32)
    mol = Chem.MolFromSmiles(smiles)
    if mol is not None:
        fp = AllChem.GetMorganFingerprintAsBitVect(
            mol, radius=2, nBits=1024, useChirality=True
        )
        DataStructs.ConvertToNumpyArray(fp, morgan)
        DataStructs.ConvertToNumpyArray(MACCSkeys.GenMACCSKeys(mol), maccs)
    return morgan, maccs


def _classes(task):
    if task == "binary":
        return 2
    if task == "multiclass":
        return 106
    raise ValueError("task must be 'binary' or 'multiclass'")


@keras.utils.register_keras_serializable(package="DFCI-Net")
class AbsoluteDifference(keras.layers.Layer):
    def call(self, inputs):
        return tf.abs(inputs[0] - inputs[1])


def _descriptor(left, right, name):
    layers = keras.layers
    return layers.Concatenate(name=name)([
        layers.Add()([left, right]), AbsoluteDifference()([left, right]),
        layers.Multiply()([left, right]),
    ])


def build_model(task):
    """Uncompiled model; inputs are (Morgan_A, Morgan_B, MACCS_A, MACCS_B)."""
    classes = _classes(task)
    layers = keras.layers
    ma = layers.Input((1024,), name="morgan_a")
    mb = layers.Input((1024,), name="morgan_b")
    ka = layers.Input((167,), name="maccs_a")
    kb = layers.Input((167,), name="maccs_b")
    direct = _descriptor(ma, mb, "morgan_pair_descriptor")
    pa = layers.Dense(64, use_bias=False, name="cross_proj_a")(ma)
    pb = layers.Dense(64, use_bias=False, name="cross_proj_b")(mb)
    cross = layers.Multiply()([pa, pb])
    cross = layers.Dense(64, activation="relu", name="cross_dense")(cross)
    cross = layers.Dropout(0.3, name="cross_dropout")(cross)
    keys = _descriptor(ka, kb, "maccs_pair_descriptor")
    keys = layers.Dense(64, activation="relu", name="maccs_dense")(keys)
    keys = layers.Dropout(0.1, name="maccs_dropout")(keys)
    fused = layers.Concatenate(name="three_branch_fusion")([direct, cross, keys])
    regularizer = keras.regularizers.l2(0.003524291993138782)
    head = [
        layers.Dense(436, activation="relu", name="dense_436"),
        layers.Dense(256, activation="relu", kernel_regularizer=regularizer, name="dense_256"),
        layers.Dropout(0.3326933041901533, name="dropout_1"),
        layers.Dense(128, activation="relu", kernel_regularizer=regularizer, name="dense_128_a"),
        layers.BatchNormalization(name="batch_norm_1"),
        layers.Dropout(0.241, name="dropout_2"),
        layers.Dense(128, activation="relu", kernel_regularizer=regularizer, name="dense_128_b"),
        layers.Dropout(0.3326933041901533, name="dropout_3"),
        layers.Dense(100, activation="relu", kernel_regularizer=regularizer, name="dense_100"),
        layers.BatchNormalization(name="batch_norm_2"),
        layers.Dropout(0.241, name="dropout_4"),
        layers.Dense(1 if classes == 2 else 106,
                     activation="sigmoid" if classes == 2 else "softmax", name="ddi_probability"),
    ]
    for layer in head:
        fused = layer(fused)
    return keras.Model((ma, mb, ka, kb), fused, name="DFCI_Net")


def cb_focal_loss(task, class_count_labels, *, beta, gamma, label_smoothing):
    """Count hard labels from the caller's explicit frequency-estimation pool."""
    classes = _classes(task)
    labels = _labels(class_count_labels, classes)
    if (not np.isfinite([beta, gamma, label_smoothing]).all()
            or not 0 <= beta < 1 or gamma < 0 or not 0 <= label_smoothing <= 1):
        raise ValueError("Invalid CB-Focal parameters")
    counts = np.bincount(labels, minlength=classes).astype(np.float64)
    weights = (1.0 - beta) / (1.0 - np.power(beta, np.maximum(counts, 1.0)))
    weights /= np.mean(weights[counts > 0])
    weights = tf.constant(np.clip(weights, 0.25, 4.0).astype(np.float32))

    def loss(y_true, y_pred):
        y = tf.cast(y_true, tf.float32)
        p = tf.clip_by_value(tf.cast(y_pred, tf.float32), 1e-7, 1.0 - 1e-7)
        if classes == 2:
            y = tf.reshape(y, (-1, 1))
            if label_smoothing:
                smooth = tf.cast(label_smoothing, tf.float32)
                y = y * (1.0 - smooth) + 0.5 * smooth
            pt = y * p + (1.0 - y) * (1.0 - p)
            ce = -(y * tf.math.log(p) + (1.0 - y) * tf.math.log(1.0 - p))
            sample_weight = y * weights[1] + (1.0 - y) * weights[0]
            return tf.reduce_mean(sample_weight * tf.pow(1.0 - pt, gamma) * ce)
        if label_smoothing:
            smooth = tf.cast(label_smoothing, tf.float32)
            y = y * (1.0 - smooth) + smooth / tf.cast(106, tf.float32)
        ce = -y * tf.math.log(p)
        sample_weight = tf.reduce_sum(weights * y, axis=-1)
        return tf.reduce_mean(sample_weight * tf.reduce_sum(tf.pow(1.0 - p, gamma) * ce, axis=-1))

    loss.__name__ = "cb_focal_loss"
    return loss


def _labels(values, classes):
    values = np.asarray(values)
    if values.ndim != 1 or not len(values):
        raise ValueError("Labels must be a nonempty one-dimensional integer array")
    labels = values.astype(np.int64)
    if np.any(values != labels) or np.any(labels < 0) or np.any(labels >= classes):
        raise ValueError("Labels must be integer class indices in the task's range")
    return labels


class _PairBatches(keras.utils.Sequence):
    def __init__(self, inputs, labels, batch_size, shuffle):
        super().__init__()
        self.inputs = tuple(np.asarray(x, dtype=np.float32) for x in inputs)
        self.labels = labels
        if int(batch_size) != batch_size or batch_size <= 0:
            raise ValueError("batch_size must be a positive integer")
        self.batch_size = int(batch_size)
        expected = tuple((len(labels), d) for d in (1024, 1024, 167, 167))
        if tuple(x.shape for x in self.inputs) != expected:
            raise ValueError("Expected four arrays with widths (1024, 1024, 167, 167)")
        self.indices = np.arange(len(labels))
        self.shuffle = shuffle
        self.on_epoch_end()

    def __len__(self):
        return (len(self.indices) + self.batch_size - 1) // self.batch_size

    def __getitem__(self, index):
        ids = self.indices[index * self.batch_size:(index + 1) * self.batch_size]
        return tuple(x[ids] for x in self.inputs), self.labels[ids]

    def on_epoch_end(self):
        if self.shuffle:
            np.random.shuffle(self.indices)


def train(task, inputs, labels, validation_data, checkpoint_path, *,
          class_count_labels, learning_rate, beta, gamma, label_smoothing,
          epochs, batch_size):
    """Use caller-supplied splits/settings; checkpoint_path must end in .weights.h5."""
    if int(epochs) != epochs or epochs <= 0:
        raise ValueError("epochs must be a positive integer")
    if not np.isfinite(learning_rate) or learning_rate <= 0:
        raise ValueError("learning_rate must be finite and positive")
    classes = _classes(task)
    y = _labels(labels, classes)
    vx, vy = validation_data
    vy = _labels(vy, classes)
    if classes == 106:
        y = keras.utils.to_categorical(y, 106).astype(np.float32)
        vy = keras.utils.to_categorical(vy, 106).astype(np.float32)
    model = build_model(task)
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
        loss=cb_focal_loss(task, class_count_labels, beta=beta,
                           gamma=gamma, label_smoothing=label_smoothing),
        metrics=["accuracy"],
    )
    callbacks = [
        keras.callbacks.ModelCheckpoint(str(checkpoint_path), monitor="val_loss", mode="min",
                                        save_best_only=True, save_weights_only=True),
        keras.callbacks.EarlyStopping(monitor="val_loss", mode="min", patience=15,
                                      restore_best_weights=(classes == 106)),
        keras.callbacks.ReduceLROnPlateau(monitor="val_loss", mode="min", factor=0.5,
                                         patience=4, min_lr=1e-6),
    ]
    history = model.fit(
        _PairBatches(inputs, y, batch_size, True),
        validation_data=_PairBatches(vx, vy, batch_size, False),
        epochs=int(epochs), callbacks=callbacks,
    )
    val_loss = np.asarray(history.history.get("val_loss", []), dtype=np.float64)
    if not len(val_loss) or not np.isfinite(val_loss).all():
        raise ValueError("A finite validation-loss history is required to select weights")
    model.load_weights(str(checkpoint_path))
    return model, history
